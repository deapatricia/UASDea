<?php

use App\Http\Controllers\AccountController;
use App\Http\Controllers\BookController;
use App\Http\Controllers\CartController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});
Route::get('/home', function () {
    return view('home');
});
Route::get('/login', function () {
    return view('login');
});
Route::get('/register', function () {
    return view('register');
});
Route::get('/profile', function () {
    return view('profile');
});
Route::get('/updaterole', function () {
    return view('updaterole');
});
Route::get('/home', [BookController::class, 'HomeView']);

Route::get('/detail/{id}', [BookController::class, 'DetailView']);

Route::post('/login', [AccountController::class, 'login']);

Route::put('/update/{id}/', [AccountController::class, 'updateProfile']);

Route::put('/updateRole/{id}', [AccountController::class, 'updateRole']);

Route::get('/logout', function () {
    Session::forget('user');
    Auth::logout();
    return redirect('/');
});

Route::post('/signup', [AccountController::class, 'register']);

Route::post('/addToCart', [CartController::class, 'addToCart']);

Route::delete('/deleteCart/{id}', [CartController::class, 'deleteCart']);

Route::delete('/deleteAccount/{id}', [AccountController::class, 'deleteAccount']);

Route::delete('/rent/{id}', [CartController::class, 'Rent']);

Route::get('/cart', [CartController::class, 'CartView']);

Route::get('/updaterole/{id}', [AccountController::class, 'updateRoleView']);

Route::get('/manage', [AccountController::class, 'ManageView']);

