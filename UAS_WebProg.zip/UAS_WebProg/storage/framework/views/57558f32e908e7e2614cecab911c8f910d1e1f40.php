<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="/css/profile.css">
</head>
<body>
    <?php echo e(View::make('layout.header')); ?>

    <?php echo e(View::make('layout.navbar')); ?>

    
    <div class="profile-box">
        <div class="profile-in-box">
            <div class="profile_img">
                <img width="100%" height="100%"src="<?php echo e(Storage::url(Auth::user()->display_picture)); ?>">
            </div>
            <form action="/update/<?php echo e(Auth::user()->id); ?>/" method="POST" enctype="multipart/form-data">
                    <?php echo e(method_field('PUT')); ?>

                    <?php echo csrf_field(); ?>
            <div class="profile-content">
                <div class="profile">
                    <p>First Name:</p>
                    <input type="text" name="first_name" id="first_name" value="<?php echo e(Auth::user()->first_name); ?>">
                </div>
                <div class="profile">
                    <p>Last Name:</p>
                    <input type="text" name="last_name" id="last_name" value="<?php echo e(Auth::user()->last_name); ?>">
                </div>
                <div class="profile">
                    <p>Gender:</p>
                    <div class="profile_1">
                        <?php if(Auth::user()->gender_id == 1): ?>
                        <div class="male">
                            <input type="radio" value="1" name="gender_id" id="gender" checked>
                            <label for="male">Male</label>
                        </div>
                        <div class="female">
                        <input type="radio" value="2" name="gender_id" id="gender" >
                            <label for="female">Female</label>
                        </div>
                        <?php else: ?>
                        <div class="male">
                            <input type="radio" value="1" name="gender_id" id="gender" >
                            <label for="male">Male</label>
                        </div>
                        <div class="female">
                        <input type="radio" value="2" name="gender_id" id="gender" checked>
                            <label for="female">Female</label>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="profile">
                    <p>Password:</p>
                    <input type="password" name="password" id="password" value="<?php echo e(Auth::user()->password); ?>">
                </div>
            </div>
            <div class="profile-content">
                <div class="profile">
                    <p>Middle Name:</p>
                    <input type="text" name="middle_name" id="middle_name" value="<?php echo e(Auth::user()->middle_name); ?>">
                </div>
                <div class="profile">
                    <p>Email:</p>
                    <input type="text" name="email" id="email" value="<?php echo e(Auth::user()->email); ?>">
                </div>
                <div class="profile">
                    <p>Role:</p>
                    <?php if(Auth::user()->role_id == 1): ?>
                    <p class="rl">User</p>
                    <?php else: ?>
                    <p class="rl">Admin</p>
                    <?php endif; ?>
                </div>
                <div class="profile">
                    <p>Display Picture:</p>
                    <div class="profile_1">
                    <input type="file" id="img" name="image">
                    </div>
                </div>
            </div>
        </div>
        <input class="save_profile" type="submit" value="Save">
        </form>
    </div>
    
    <?php echo e(View::make('layout.footer')); ?>

</body>
</html><?php /**PATH D:\Joki\Dea\Ebook-Dea\resources\views/profile.blade.php ENDPATH**/ ?>