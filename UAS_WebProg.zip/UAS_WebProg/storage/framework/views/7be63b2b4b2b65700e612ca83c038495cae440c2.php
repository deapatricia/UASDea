<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <style>
        *{
            margin:0;
            padding: 0;
        }

        .footer-box{
            width: 100%;
            height: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #9ec5fe;
        }

        .footer-box p{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: black;
            font-size: 17px;
        }
    </style>

    <div class="footer-box">
        <p>© Amazing E-Book 2022</p>
    </div>
</body>
<?php /**PATH C:\DEA\SEMESTER 5\WebProg\UAS\UAS_WebProg\resources\views/layout/footer.blade.php ENDPATH**/ ?>