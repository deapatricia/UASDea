<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="/css/cart.css">
</head>
<body>
    <?php echo e(View::make('layout.header')); ?>

    <?php echo e(View::make('layout.navbar')); ?>


    <div class="cart-box">
        <table>
            <tr>
                <th>Title</th>
            </tr>
            <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td>
                    <div class="cart-in-box">
                        <p><?php echo e($book->book->title); ?></p>
                        <form action="/deleteCart/<?php echo e($book->id); ?>" method="POST">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo csrf_field(); ?>
                            <input type="submit" value="Delete">
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td>No Books to Rent</td>
            </tr>
            <?php endif; ?>
        </table>

        <div class="submit">
                <form action="/rent/<?php echo e(Auth::user()->id); ?>" method="POST" enctype="multipart/form-data" >
                    <?php echo e(method_field('DELETE')); ?>

                    <?php echo csrf_field(); ?>
                    <input type="submit" value="Rent"></input>
                </form>
            </div>
        
    </div>

    <?php echo e(View::make('layout.footer')); ?>

</body>
</html><?php /**PATH D:\Joki\Dea\Ebook-Dea\resources\views/cart.blade.php ENDPATH**/ ?>