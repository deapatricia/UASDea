<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="/css/home.css">
</head>
<body>
    <?php echo e(View::make('layout.header')); ?>

    <?php echo e(View::make('layout.navbar')); ?>


    <div class="home-box">
        <table>
            <tr>
                <th>Author</th>
                <th>Title</th>
            </tr>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($book->author); ?></td>
                <td><a href="/detail/<?php echo e($book->id); ?>"><?php echo e($book->title); ?></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>

    <?php echo e(View::make('layout.footer')); ?>

</body>
</html><?php /**PATH C:\DEA\SEMESTER 5\WebProg\UAS\UAS_WebProg\resources\views/home.blade.php ENDPATH**/ ?>