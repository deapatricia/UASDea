<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Role</title>
</head>
<body>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Role</title>
    <link rel="stylesheet" href="/asset/css/updaterole.css">
</head>
<body>
    <style>
        *{
    margin: 0;
    padding: 0;
    }

    .updaterole-box{
        width:100%;
        height:82.2vh;
    }

    .updaterole-in-box{
        margin: 40px 0 0 40px;
    }

    .updaterole-in-box h2{
        font-family: Arial, Helvetica;
        padding-bottom: 30px;
    }

    .rl{
        font-family: Arial;
        margin-right: 112px;
        font-weight: 600;
    }

    .rl select{
        padding: 4px 15px;
    }

    .temp{
        width: 15%;
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
    }

    .temp p{
        width: 50px;
    }

    .submit input{
        margin-top: 20px;
        margin-left: 905px;
        padding: 8px 20px;
        background-color: #ffda6a;
        cursor: pointer;
    }

    .save_update{
        border-style: none;
        border-radius: 6px;
        margin-top: 20px;
        padding: 10px 25px;
        background-color: #ffda6a;
        cursor: pointer;
    }

    .save_update:hover{
        background-color: #ffe699;
        transform: scale(1.2);
    }
    </style>
    <?php echo e(View::make('layout.header')); ?>

    <?php echo e(View::make('layout.navbar')); ?>

    
    <div class="updaterole-box">
        <div class="updaterole-in-box">
            <h2>Update Role</h2>
            <div class="temp">
            <p>Role:</p>
            <form action="/updateRole/<?php echo e($users->id); ?>" method="POST" enctype="multipart/form-data">
                <?php echo e(method_field('PUT')); ?>

                <?php echo csrf_field(); ?>
                <div class="rl">
                    <select name="role_id" id="role_id">
                        <option value="1">User</option>
                        <option value="2">Admin</option>
                    </select>
                </div>
                <input class="save_update" type="submit" value="Save">
                </form>
            </div>
        </div>
    </div>
        
    <?php echo e(View::make('layout.footer')); ?>

</body>
</html>
</body>
</html><?php /**PATH D:\Joki\Dea\Ebook-Dea\resources\views/updaterole.blade.php ENDPATH**/ ?>