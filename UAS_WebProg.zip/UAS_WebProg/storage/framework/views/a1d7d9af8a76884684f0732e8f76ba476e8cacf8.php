<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <style>
        *{
            margin:0;
            padding: 0;
        }

        .header-box{
            width: 100%;
            height: 80px;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #9ec5fe;
        }

        .header-box h1{
            font-family: Arial;
            color: black;
        }

        .logout{
            width:auto;
            height:auto;
            position: absolute;
            margin-left: 1350px;;
        }
        
        .logout a{
            font-family: Arial;
            border-radius: 5px;
            background-color: #ffda6a;
            color: black;
            padding: 6px 15px;
            text-decoration: none;
        }
    </style>

    <div class="header-box">
        <h1>Amazing E-Book</h1>
            <?php if(Session::has('user')): ?>
            <div class="logout">
                <a href="/logout">Logout</a>
            </div>
            <?php endif; ?>
    </div>
</body>
<?php /**PATH D:\Joki\Dea\Ebook-Dea\resources\views/layout/header.blade.php ENDPATH**/ ?>