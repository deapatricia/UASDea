<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="/css/login.css">
</head>
<body>
    <?php echo e(View::make('layout.header')); ?>

    
    <div class="login-box">
        <div class="login-in-box">
            <h1>Login</h1>
            <form action="/login" method="POST">
                <?php echo csrf_field(); ?>
            <div class="box-temp">
                <p>Email Address:</p>
                <input type="email" name="email" id="email">
            </div>
            <div class="temp_login">
                <div class="box-temp">
                    <p>Password:</p>
                    <input type="password" name="password" id="password">
                </div>
                <a href="/register">Dont't have account? click here to sign up</a>
            </div>
        </div>
        <input class="submit" type="submit" value="Login">
        </form>
    </div>
    <?php echo e(View::make('layout.footer')); ?>

</body>
</html><?php /**PATH D:\Joki\Dea\Ebook-Dea\resources\views/login.blade.php ENDPATH**/ ?>