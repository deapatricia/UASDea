<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('books')->insert([
            'title' => 'Naruto',
            'author' =>'Masashi Kishimoto',
            'description' => 'Naruto is a Japanese manga series written and illustrated by Masashi Kishimoto. It tells the story of Naruto Uzumaki, a young ninja who seeks recognition from his peers and dreams of becoming the Hokage, the leader of his village.',
        ]);

        DB::table('books')->insert([
            'title' => 'Attack on Titan',
            'author' =>'Hajime Isayama',
            'description' => 'In this post-apocalytpic sci-fi story, humanity has been devastated by the bizarre, giant humanoids known as the Titans. Little is known about where they came from or why they are bent on consuming mankind. Seemingly unintelligent, they have roamed the world for years, killing everyone they see.',
        ]);

        DB::table('books')->insert([
            'title' => 'Doraemon',
            'author' =>'A Coloring Book',
            'description' => 'Doraemon is one of the famous Japanese cartoons about the adorable robot cat Doraemon. If you love Doraemon then the book "Doraemon coloring book" is the book for you. The book has all the characters with 79 pictures for you to freely color.',
        ]);
        
        DB::table('books')->insert([
            'title' => 'Tom & Jerry',
            'author' =>'Benjamin Bird',
            'description' => 'This Tom and Jerry digital, interactive picture book holds a surprise on each page! Where is Jerry hiding? On the title page, on the back cover, or somewhere in between? Little readers will howl with delight each time they open the covers and try helping Tom find the mischievous mouse. Perfect for storytime.',
        ]);
    }
}
