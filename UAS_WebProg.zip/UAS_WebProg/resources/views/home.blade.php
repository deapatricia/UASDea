<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="/css/home.css">
</head>
<body>
    {{View::make('layout.header')}}
    {{View::make('layout.navbar')}}

    <div class="home-box">
        <table>
            <tr>
                <th>Author</th>
                <th>Title</th>
            </tr>
            @foreach($books as $book)
            <tr>
                <td>{{$book->author}}</td>
                <td><a href="/detail/{{$book->id}}">{{$book->title}}</a></td>
            </tr>
            @endforeach
        </table>
    </div>

    {{View::make('layout.footer')}}
</body>
</html>