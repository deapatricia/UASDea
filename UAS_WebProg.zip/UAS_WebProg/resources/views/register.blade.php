<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="/css/register.css">
</head>
<body>
    {{View::make('layout.header')}}

    <div class="register-box">
        <h1>Sign Up</h1>
        <form action="/signup" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="register-in-box">
            <div class="register">
                <div class="register-temp">
                    <p>First Name:</p>
                    <input type="text" name="first_name" id="first_name">
                </div>
                <div class="register-temp">
                    <p>Last Name:</p>
                    <input type="text" name="last_name" id="last_name">
                </div>
                <div class="register-temp">
                    <p>Gender:</p>
                    <div class="register-temp-1">
                        <div class="male">
                            <input type="radio" id="gender_id" value="1" name="gender_id">
                            <label for="male">Male</label>
                        </div>
                        <div class="female">
                        <input type="radio" id="gender_id" value="2" name="gender_id">
                            <label for="female">Female</label>
                        </div>
                    </div>
                </div>
                <div class="register-temp">
                    <p>Password:</p>
                    <input type="password" name="password" id="password">
                </div>
            </div>
            <div class="register">
                <div class="register-temp">
                    <p>Middle Name:</p>
                    <input type="text" name="middle_name" id="middle_name">
                </div>
                <div class="register-temp">
                    <p>Email:</p>
                    <input type="text" name="email" id="email" value="">
                </div>
                <div class="register-temp">
                    <p>Role:</p>
                        <div class="rl">
                            <select name="role_id" id="role_id">
                                <option id="role_id" value="1">User</option>
                                <option id="role_id" value="2">Admin</option>
                            </select>
                        </div>
                </div>
                <div class="register-temp">
                    <p>Display Picture:</p>
                    <div class="register-temp-1">
                    <input type="file" name="image">
                    </div>
                </div>
            </div>
        </div>
        <input class="save" type="submit" value="Save">
    </form>
    </div>

    {{View::make('layout.footer')}}
</body>
</html>