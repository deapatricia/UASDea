<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="/css/cart.css">
</head>
<body>
    {{View::make('layout.header')}}
    {{View::make('layout.navbar')}}

    <div class="cart-box">
        <table>
            <tr>
                <th>Title</th>
            </tr>
            @forelse ($books as $book)
            <tr>
                <td>
                    <div class="cart-in-box">
                        <p>{{$book->book->title}}</p>
                        <form action="/deleteCart/{{$book->id}}" method="POST">
                            {{method_field('DELETE')}}
                            @csrf
                            <input type="submit" value="Delete">
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td>No Books to Rent</td>
            </tr>
            @endforelse
        </table>

        <div class="submit">
                <form action="/rent/{{Auth::user()->id}}" method="POST" enctype="multipart/form-data" >
                    {{method_field('DELETE')}}
                    @csrf
                    <input type="submit" value="Rent"></input>
                </form>
            </div>
        
    </div>

    {{View::make('layout.footer')}}
</body>
</html>