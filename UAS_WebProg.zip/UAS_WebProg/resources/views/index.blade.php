<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Amazing E-Book</title>
    <link rel="stylesheet" href="/css/index.css">
</head>
<body>
    {{View::make('layout.header')}}

    <div class="index-box">
        <div class="index-in-box">
            <h1>Find And Rent Your E-Book Here</h1>
            <div class="option">
                <a href="/login">Login</a>
                <a href="/register">Sign Up</a>
            </div>
        </div>
    </div>


    {{View::make('layout.footer')}}
</body>
</html>