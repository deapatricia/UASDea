<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail</title>
    <link rel="stylesheet" href="/css/detail.css">
</head>
<body>
    {{View::make('layout.header')}}
    {{View::make('layout.navbar')}}

    <div class="detail-box">
        <div class="detail-in-box">
            <h2>E-Book Detail</h2>
            <div class="detail-temp">
                <div class="detail-in-temp">
                    <p class="temp">title:</p>
                    <p class="tempp">{{$books->title}}</p>
                </div>
                <div class="detail-in-temp">
                    <p class="temp">Author:</p>
                    <p class="tempp">{{$books->author}}</p>
                </div>
                <div class="detail-in-temp">
                    <p class="temp">Description:</p>
                    <p class="tempp">{{$books->description}}</p>
                </div>
            </div>
            <div class="submit">
                <form action="/addToCart" method="POST" enctype="multipart/form-data" >
                @csrf
                    <input type="hidden" name="book_id" value="{{$books->id}}">
                    <input type="submit" value="Rent"></input>
                </form>
            </div>
        </div>
    </div>

    {{View::make('layout.footer')}}
</body>
</html>