<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <style>
        *{
    margin:0;
    padding: 0;
}

.navbar-box {
    width:100%;
    background-color: #ffda6a;
    height: 40px;
    display: flex;
    justify-content: center;
    align-items: center;
}

.navbar-in-box {
    display: flex;
    justify-content: space-between;
    width: 500px;
}

.navbar-in-box a{
    font-family: arial;
    padding: 4px 8px;
    text-decoration: none;
    color: black;
    font-weight: bold;
}

.navbar-in-box a:hover{
    transform: scale(1.2);
}

    </style>

<div class="navbar-box">
        <div class="navbar-in-box">
            <a href="/home">Home</a>
            <a href="/cart">Cart</a>
            <a href="/profile">Profile</a>
            <!-- @if (Session::has('user'))
                @if(Auth::user()->role_id == 2) -->
                <a href="/manage">Account Maintenance</a>
            <!-- @endif
            @endif   -->
        </div>
    </div>
</body>
