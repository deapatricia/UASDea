<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Maintenance</title>
    <link rel="stylesheet" href="/css/manage.css">
</head>
<body>
    {{View::make('layout.header')}}
    {{View::make('layout.navbar')}}

    <div class="manage-box">
    <table>
            <tr>
                <th>Account</th>
                <th>Action</th>
            </tr>
            @foreach($users as $user)
            <tr>
                <td>
                    @if($user->role_id == 1)
                    {{$user->first_name}} {{$user->middle_name}} {{$user->last_name}} - User
                    @else
                    {{$user->first_name}} {{$user->middle_name}} {{$user->last_name}} - Admin
                    @endif
                </td>
                <td>
                    <div class="temp_manage">
                        <div class="manage-in-box">
                                <form action="/deleteAccount/{{$user->id}}" method="POST">
                                    {{method_field('DELETE')}}
                                    @csrf
                                    <input type="submit" value="Delete">
                                </form>
                            </div>
                            <div class="manage-in-box">
                                <form action="/updaterole/{{$user->id}}">
                                    <input type="submit" value="Update">
                                </form>
                            </div>
                    </div>
                </td>
            </tr>
            @endforeach
        </table>
    </div>

    {{View::make('layout.footer')}}
</body>
</html>