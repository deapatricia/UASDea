<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Order;


use Illuminate\Support\Facades\Auth;

class BookController extends Controller
{
    public function HomeView(){
        $book = Book::all();
        return view('home', ['books'=> $book]);
    }
    function DetailView($id){
        $book = Book::find($id);
        return view('detail', ['books' => $book]);
    }
   
}
