<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class AccountController extends Controller
{
    function register(Request $req){

        $file = $req->file('image');
        $imageName = time().'.'.$file->getClientOriginalExtension();
        Storage::putFileAs('public/images', $file, $imageName);
        $imageName = 'images/'.$imageName;

        $req->validate([
            'first_name'=>'required|string|max:25',
            'middle_name'=>'nullable|string|max:25',
            'last_name'=>'required|string|max:25',
            'email'=>'required',
            'role_id'=>'required',
            'password'=>'required|min:8',
            'gender_id'=>'required',
            'image'=>'required|image',
        ]);

        $user = new User();
        $user->first_name=$req->first_name;
        $user->middle_name=$req->middle_name;
        $user->last_name=$req->last_name;
        $user->email=$req->email;
        $user->password=$req->password;
        $user->role_id=$req->role_id;        
        $user->gender_id=$req->gender_id;
        $user->display_picture = $imageName;

        $user->save(); 
        return redirect('/login');
    }

    function login(Request $req)
    {   
        $req->validate([
            'email' => 'required',
            'password'=>'required'
        ]);

        $user= User::where(['email'=>$req->email])->first();
        if(!$user || $req->password !=$user->password)
        {
            return redirect()->back()->withErrors($user);
        }
        else
        {
            $req->session()->put('user', $user);
            Auth::login($user);
            return redirect('/home');
        }

    }  

    public function updateProfile(Request $req, $id){
        
        $file = $req->file('image');
        $user = User::find($id);

        $req->validate([
            'first_name'=>'required|string|max:25',
            'middle_name'=>'nullable|string|max:25',
            'last_name'=>'required|string|max:25',
            'email'=>'required',
            'password'=>'required|min:8',
            'gender_id'=>'required',
            'image'=>'image',
        ]);

        $user->first_name = $req->first_name != null ? $req->first_name : $user->first_name;
        $user->middle_name = $req->middle_name != null ? $req->middle_name : $user->middle_name;
        $user->last_name = $req->last_name != null ? $req->last_name : $user->last_name;
        $user->email = $req->email != null ? $req->email : $user->email;
        $user->password = $req->password != null ? $req->password : $user->password;
        $user->gender_id = $req->gender_id != null ? $req->gender_id : $user->gender_id;
        
        if($file != null){
            $imageName = time().'.'.$file->getClientOriginalExtension();
            Storage::putFileAs('public/images', $file, $imageName);
            $imageName = 'images/'.$imageName;
    
            Storage::delete('public/'. $user->images);
            $user->display_picture = $imageName;
        }
        else{
            $user->display_picture = $user->display_picture;
        }

        $user->save();
        
        return redirect('/home');
    }

    function ManageView(){
        $user = User::all();
        return view('manage', ['users'=> $user]);
    }

    function deleteAccount(Request $req, $id){
        $user = User::find($id);

        if(isset($user)){
            $user->delete();
        }
        return redirect('manage');	
    }

    public function updateRole(Request $req, $id){
        $user = User::find($id);

        $user->role_id = $req->role_id != null ? $req->role_id : $user->role_id;
    
        $user->save();
        
        return redirect('home');
    }

    function updateRoleView($id){
        $user = User::find($id);
        return view('updaterole', ['users' => $user]);
    }

}
