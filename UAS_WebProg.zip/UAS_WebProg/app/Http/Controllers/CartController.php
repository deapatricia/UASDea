<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CartController extends Controller
{
    function addToCart(Request $req){

        if($req->session()->has('user')){
            $cart = new Order();
            $cart->user_id = $req->session()->get('user')['id'];
            $cart->book_id = $req->book_id;

            if(Order::where('user_id','=',$req->session()->get('user')['id'])
                ->where('book_id','=',$req->book_id)->exists())
            {
                return redirect()->back();
            }
            else
            {
                $cart->save();
                return redirect('home');
            } 
        }
        else{
            return redirect('/');
        }
    }

    function deleteCart(Request $req, $id){
        $book = Order::find($id);

        if(isset($book)){
            $book->delete();
        }
        return redirect('cart');	
    }

    public function Rent($id){

        $cart = Order::where('user_id', $id)->get();
  
        if(isset($cart)){
  
          $cart->each->delete();
        
        }
  
        return redirect('/home');
      }

    public function CartView(){
        $book = Order::where('user_id', Auth::id())->get();
        return view('cart', ['books'=> $book]);
    }
}
